"""
Module providing extraction attacks under a common interface.
"""
from qausalml.adversarial.attacks.extraction.functionally_equivalent_extraction import FunctionallyEquivalentExtraction
from qausalml.adversarial.attacks.extraction.copycat_cnn import CopycatCNN
from qausalml.adversarial.attacks.extraction.knockoff_nets import KnockoffNets
