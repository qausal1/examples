"""
Module providing model inversion attacks.
"""
from qausalml.adversarial.attacks.inference.model_inversion.mi_face import MIFace
