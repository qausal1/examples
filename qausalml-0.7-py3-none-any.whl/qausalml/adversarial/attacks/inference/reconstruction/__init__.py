"""
Module providing model inversion attacks.
"""
from qausalml.adversarial.attacks.inference.reconstruction.white_box import DatabaseReconstruction
