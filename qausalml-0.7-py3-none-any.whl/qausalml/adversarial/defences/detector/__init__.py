"""
Module implementing detector-based defences against adversarial attacks.
"""
from qausalml.adversarial.defences.detector import evasion
from qausalml.adversarial.defences.detector import poison
