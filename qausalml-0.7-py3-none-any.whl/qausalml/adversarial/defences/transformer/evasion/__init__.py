"""
Module implementing transformer-based defences against evasion attacks.
"""
from qausalml.adversarial.defences.transformer.evasion.defensive_distillation import DefensiveDistillation
