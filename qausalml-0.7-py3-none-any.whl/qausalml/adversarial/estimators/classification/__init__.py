"""
Classifier API for applying all attacks. Use the :class:`.Classifier` wrapper to be able to apply an attack to a
preexisting model.
"""
from qausalml.adversarial.estimators.classification.classifier import (
    ClassifierMixin,
    ClassGradientsMixin,
)

from qausalml.adversarial.estimators.classification.blackbox import BlackBoxClassifier, BlackBoxClassifierNeuralNetwork
from qausalml.adversarial.estimators.classification.catboost import CatBoostARTClassifier
from qausalml.adversarial.estimators.classification.deep_partition_ensemble import DeepPartitionEnsemble
from qausalml.adversarial.estimators.classification.detector_classifier import DetectorClassifier
from qausalml.adversarial.estimators.classification.ensemble import EnsembleClassifier
from qausalml.adversarial.estimators.classification.GPy import GPyGaussianProcessClassifier
from qausalml.adversarial.estimators.classification.keras import KerasClassifier
from qausalml.adversarial.estimators.classification.lightgbm import LightGBMClassifier
from qausalml.adversarial.estimators.classification.mxnet import MXClassifier
from qausalml.adversarial.estimators.classification.pytorch import PyTorchClassifier
from qausalml.adversarial.estimators.classification.query_efficient_bb import QueryEfficientGradientEstimationClassifier
from qausalml.adversarial.estimators.classification.scikitlearn import SklearnClassifier
from qausalml.adversarial.estimators.classification.tensorflow import (
    TFClassifier,
    TensorFlowClassifier,
    TensorFlowV2Classifier,
)
from qausalml.adversarial.estimators.classification.xgboost import XGBoostClassifier
