"""
Encoder API.
"""
from qausalml.adversarial.estimators.encoding.encoder import EncoderMixin

from qausalml.adversarial.estimators.encoding.tensorflow import TensorFlowEncoder
