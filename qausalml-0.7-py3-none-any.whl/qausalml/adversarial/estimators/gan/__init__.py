"""
GAN Estimator API.
"""
from qausalml.adversarial.estimators.gan.tensorflow import TensorFlowV2GAN
