"""
This module implements all regressors in ART.
"""
from qausalml.adversarial.estimators.regression.regressor import RegressorMixin, Regressor

from qausalml.adversarial.estimators.regression.scikitlearn import ScikitlearnRegressor

from qausalml.adversarial.estimators.regression.keras import KerasRegressor

from qausalml.adversarial.estimators.regression.pytorch import PyTorchRegressor

from qausalml.adversarial.estimators.regression.blackbox import BlackBoxRegressor
