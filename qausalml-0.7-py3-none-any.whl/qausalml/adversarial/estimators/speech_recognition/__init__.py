"""
Module containing estimators for speech recognition.
"""
from qausalml.adversarial.estimators.speech_recognition.speech_recognizer import SpeechRecognizerMixin

from qausalml.adversarial.estimators.speech_recognition.pytorch_deep_speech import PyTorchDeepSpeech
from qausalml.adversarial.estimators.speech_recognition.pytorch_espresso import PyTorchEspresso
from qausalml.adversarial.estimators.speech_recognition.tensorflow_lingvo import TensorFlowLingvoASR
