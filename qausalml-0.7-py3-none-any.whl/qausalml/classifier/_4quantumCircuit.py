#@title 5.QuantumCircuit.py{display-mode:'form'}

# -*- coding: utf-8 -*-
"""
Created on Wed Jan  5 16:01:52 2022

@author: reekm
"""
# Pennylane


import pennylane as qml
from ._2featuremap import *
from ._3layers import *
#from pennylane import numpy as np

#from layers import RY_layer,U1_layer,RZ_layer,RX_layer,U2_layer,U3_layer,PhaseShift_layer,H_layer
#from layers import entangling_layer_CNOT,entangling_layer_CZ,entangling_layer_CRX

# from featureMap import feature_map1,feature_map2,feature_map3,feature_map4,feature_map5
# from featureMap import feature_map6,feature_map7,feature_map8,feature_map9,feature_map10
# from featureMap import feature_map11,feature_map12,feature_map13,feature_map14,feature_map15
# from featureMap import feature_map16,feature_map17,feature_map18,feature_map19,feature_map20

# from Layers2 import Layers


class Quantum_circuit():
    ip = 0
    front_layer = str(5)
    op = 1
    last_layer =  str(6)
    entanglement_layer = 0
    middle_layer = str(4)
    measurement = 0
    fmap_depth = 3
    var_depth = 3
    model_id ="Hybrid"
    fmap_id = 100
    n_qubits =4


    
    def __init__(self,ip,front_layer,op,last_layer,entanglement_layer,middle_layer,measurement,fmap_depth,var_depth,model_id,featureMap_id,n_qubits):
        self.ip = ip
        self.front_layer = front_layer
        self.op = op
        self.last_layer = last_layer
        self.entanglement_layer = entanglement_layer
        self.middle_layer = middle_layer
        self.measurement = measurement
        self.fmap_depth = fmap_depth
        self.var_depth = var_depth
        self.model_id = model_id 
        self.featureMap_id = featureMap_id
        self.n_qubits = n_qubits
        self.layer = Layers(n_qubits)
        
        
        
    def get_layer(self,layerId,weights):
        if layerId == '0':
            self.layer.RY_layer(weights)
        elif layerId =='1':
            self.layer.U1_layer(weights)
        elif layerId =='2':
            self.layer.RZ_layer(weights)
        elif layerId =='3':
            self.layer.RX_layer(weights)
        elif layerId =='4':
            self.layer.U2_layer(weights)
        elif layerId =='5':
            self.layer.U3_layer(weights)
        elif layerId =='6':
            self.layer.PhaseShift_layer(weights)
        elif layerId =='7':
            self.layer.H_layer(self.n_qubits)
            
    def get_entanglement_layer(self,id,flag=False):
        if id == 0:
            self.layer.entangling_layer_CNOT(self.n_qubits,flag)
        if id ==1:
            self.layer.entangling_layer_CZ(self.n_qubits,flag)
        if id == 2:
            self.layer.entangling_layer_CRX(self.n_qubits,flag)
            
    def front_layers(self,w):
        for x in self.front_layer:
            self.get_layer(x,w)
            
    def last_layers(self,w):
        for x in self.last_layer:
            self.get_layer(x,w)
            
    def get_var_layer(self,weights):
        self.get_entanglement_layer(self.entanglement_layer)
        for x in self.middle_layer:
            self.get_layer(x,weights)
            
            
    def get_var_layer2(self,k,weights):
        self.get_entanglement_layer(self.entanglement_layer)
        for i,j in enumerate(self.middle_layer):
            self.get_layer(j,weights[(self.var_depth*i)+k])
            
    def get_expectation_value(self,measurementId):
        gate_set = [qml.PauliX, qml.PauliY, qml.PauliZ]
        exp_val = [qml.expval(gate_set[measurementId](position)) for position in range(self.n_qubits)]
        return exp_val
    
    

    def get_feature_map(self,x,qubits,reps):
        featureMap_id = self.featureMap_id
        if featureMap_id == 1:
            feature_map1(x,qubits,reps)
        elif featureMap_id == 2:
            feature_map2(x,qubits,reps)
        elif featureMap_id == 3:
            feature_map3(x,qubits,reps)
        elif featureMap_id == 4:
            feature_map4(x,qubits,reps)
        elif featureMap_id == 5:
            feature_map5(x,qubits,reps)
        elif featureMap_id == 6:
            feature_map6(x,qubits,reps)
        elif featureMap_id == 7:
            feature_map7(x,qubits,reps)
        elif featureMap_id == 8:
            feature_map8(x,qubits,reps)
        elif featureMap_id == 9:
            feature_map9(x,qubits,reps)
        elif featureMap_id == 10:
            feature_map10(x,qubits,reps)
        elif featureMap_id == 11:
            feature_map11(x,qubits,reps)
        elif featureMap_id == 12:
            feature_map12(x,qubits,reps)
        elif featureMap_id == 13:
            feature_map13(x,qubits,reps)
        elif featureMap_id == 14:
            feature_map14(x,qubits,reps)
        elif featureMap_id == 15:
            feature_map15(x,qubits,reps)
        elif featureMap_id == 16:
            feature_map16(x,qubits,reps)
        elif featureMap_id == 17:
            feature_map17(x,qubits,reps)
        elif featureMap_id == 18:
            feature_map18(x,qubits,reps)
        elif featureMap_id == 19:
            feature_map19(x,qubits,reps)
        elif featureMap_id == 20:
            feature_map20(x,qubits,reps)