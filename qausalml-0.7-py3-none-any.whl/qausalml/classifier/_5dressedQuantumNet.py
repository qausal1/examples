#@title 5.DressedQuantumNet.py
import pennylane as qml
from ._1config import get_q_device
from ._4quantumCircuit import Quantum_circuit

from pennylane import numpy as np
import torch
import torch.nn.functional as F
import torch.nn as nn

class DressedQuantumNet(nn.Module):
    def __init__(self,q_device_params,n_classes,num_ftrs,key,n_qubits):
        super().__init__()
        self.ip,self.front_layer,self.op,self.last_layer,\
        self.entanglement_layer,self.middle_layer,self.measurement,\
        self.fmap_depth,self.var_depth,self.model_id,self.featureMap_id = key
        self.n_qubits = n_qubits 
        self.pre_net = nn.Linear(num_ftrs, self.n_qubits)
        weight_shapes={'weights':(self.var_depth * len(self.middle_layer) ,self.n_qubits)}
        self.q_device_params=q_device_params
        self.n_classes=n_classes
        dev = get_q_device(self.q_device_params,self.n_qubits)
        qnode = qml.QNode(self.quantum_net,dev,interface="torch")
        self.qlayer = qml.qnn.TorchLayer(qnode,weight_shapes)
        self.post_net = nn.Linear(self.n_qubits, self.n_classes)
        self.key = key
        # print(self.key)
       

    def forward(self, input_features):
        pre_out = self.pre_net(input_features)
        # pre_out = F.relu(self.pre_net(input_features))
        q_in = torch.relu(pre_out) * np.pi / 2.0 #q_in shape: [batch size,no.of qubits]
        q_out = torch.Tensor(0, self.n_qubits)
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        q_out=q_out.to(device)

        for elem in q_in:
            q_out_elem = self.qlayer(elem).float().unsqueeze(0)
            q_out = torch.cat((q_out, q_out_elem))
            q_out=q_out.to(device)
     
        output = self.post_net(q_out)
        return F.softmax(output,dim=1)
    
    def quantum_net(self,inputs, weights):
        qc = Quantum_circuit(self.ip,self.front_layer,self.op,self.last_layer,
                             self.entanglement_layer,self.middle_layer,self.measurement,
                             self.fmap_depth,self.var_depth,self.model_id,self.featureMap_id,self.n_qubits )
        
        if qc.ip ==1:
            qc.front_layers(inputs)

        # try with this featuremap layer
        # qc.get_feature_map(inputs,n_qubits,int(qc.fmap_depth))

        for k in range(int(qc.var_depth)):
            qc.get_var_layer2(k,weights)
            
        qc.get_entanglement_layer(qc.entanglement_layer,True)
        
        if qc.op == 1:
            qc.last_layers(inputs)
            
        exp_vals = qc.get_expectation_value(int(qc.measurement))
        return tuple(exp_vals)

# model=DressedQuantumNet()
# print(model)
            