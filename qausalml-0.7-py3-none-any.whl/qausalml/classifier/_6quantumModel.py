#@title QuantumMOdel.py{display-mode:"form"}
import torchvision
from ._5dressedQuantumNet import DressedQuantumNet

class QuantumModel:
    model_hybrid = None
    def __init__(self,key,q_device_params,n_classes,model_name= "resnet18",n_qubits = 4):
#        self.trial=trial
        self.model_name = model_name
        self.n_qubits = n_qubits
        self.key = key
        self.q_device_params=q_device_params
        self.n_classes=n_classes
        self.quantum_model()
        
    def quantum_model(self):
        
        if self.model_name == "resnet18":
            self.model_hybrid = torchvision.models.resnet18(pretrained=True)
            for param in self.model_hybrid.parameters():
                param.requires_grad = False 
            num_ftrs = self.model_hybrid.fc.in_features
            self.model_hybrid.fc = DressedQuantumNet(self.q_device_params,self.n_classes,num_ftrs,self.key,self.n_qubits)
#            model = model_classical
#            for param in model_hybrid.parameters():
#                 param.requires_grad = False
            
        elif self.model_name == "alexnet":
            self.model_hybrid = torchvision.models.alexnet(pretrained=True)
            for param in self.model_hybrid.parameters():
                param.requires_grad = False    
            num_ftrs =  self.model_hybrid.classifier[1].in_features
            self.model_hybrid.classifier = DressedQuantumNet(self.q_device_params,self.n_classes,num_ftrs,self.key,self.n_qubits)
    #        model = model_classical
            
        elif self.model_name == "vgg16":
            self.model_hybrid = torchvision.models.vgg16(pretrained=True)
            for param in self.model_hybrid.parameters():
                param.requires_grad = False   
            num_ftrs = self.model_hybrid.classifier[0].in_features
            self.model_hybrid.classifier = DressedQuantumNet(self.q_device_params,self.n_classes,num_ftrs,self.key,self.n_qubits)
        
        elif self.model_name == "inception_v3":
            self.model_hybrid = torchvision.models.inception_v3(pretrained=True)
#            print("Inside inception")
            for param in self.model_hybrid.parameters():
                param.requires_grad = False
            num_ftrs = self.model_hybrid.fc.in_features
            self.model_hybrid.fc =  DressedQuantumNet(self.q_device_params,self.n_classes,num_ftrs,self.key,self.n_qubits)
            
    def get_model(self):
        return self.model_hybrid
    
    
