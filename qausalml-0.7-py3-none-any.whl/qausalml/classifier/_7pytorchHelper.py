
"""
Created on Wed Jan  5 04:01:13 2022

@author: reekm
"""
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
import os
import time
import copy
from torchvision import datasets, transforms
# from ._1config import data_dir

os.environ["OMP_NUM_THREADS"] = "1"
torch.manual_seed(42)


class pytorch_helper:
    def __init__(self,model,data_dir,batch_size,model_name):
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
#        self.data_dir = "data/dataset1"
        # self.data_dir = "histo_500subset/"
        self.data_dir = data_dir
#        C:\Users\reekm\Documents\QausalAI\GastroDataset\v1\kvasir_dataset_v2_full
        self.model = model
        self.model.to(self.device)
        self.batch_size = batch_size
        self.model_name = model_name
        
    
        
    def dataset_transform(self):
        
        data_transforms = {
            "train": transforms.Compose(
                [
                    # transforms.RandomResizedCrop(224),     # uncomment for data augmentation
                    # transforms.RandomHorizontalFlip(),     # uncomment for data augmentation
                    transforms.Resize(256),
                    transforms.CenterCrop(224),
                    transforms.ToTensor(),
                    # Normalize input channels using mean values and standard deviations of ImageNet.
                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
                ]
            ),
            "test": transforms.Compose(
                [
                    transforms.Resize(256),
                    transforms.CenterCrop(224),
                    transforms.ToTensor(),
                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
                ]
            ),
            }
        
        return data_transforms
    
    def dataset_transform_inception(self):
        
        data_transforms = {
            "train": transforms.Compose(
                [
                    # transforms.RandomResizedCrop(224),     # uncomment for data augmentation
                    # transforms.RandomHorizontalFlip(),     # uncomment for data augmentation
                    transforms.Resize(256),
                    transforms.CenterCrop(299),
                    transforms.ToTensor(),
                    # Normalize input channels using mean values and standard deviations of ImageNet.
                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
                ]
            ),
            "test": transforms.Compose(
                [
                    transforms.Resize(256),
                    transforms.CenterCrop(299),
                    transforms.ToTensor(),
                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
                ]
            ),
            }
        
        return data_transforms
    
    
    def dataset(self):
        image_datasets = None
        if self.model_name == "inception_v3":
            image_datasets = {
                x if x == "train" else "validation": datasets.ImageFolder(
                    os.path.join(self.data_dir, x), self.dataset_transform_inception()[x]
                )
                for x in ["train", "test"]
            }
        else:
            image_datasets = {
                x if x == "train" else "validation": datasets.ImageFolder(
                    os.path.join(self.data_dir, x), self.dataset_transform()[x]
                )
                for x in ["train", "test"]
            }
            
            
#        print(image_datasets)
        return image_datasets
    
    def dataset_sizes(self):
        dataset_size = {x: len(self.dataset()[x]) for x in ["train", "validation"]}
        return dataset_size
    
    def class_names(self):
        class_names = self.dataset()["train"].classes
        return class_names
    
    def dataset_dataloaders(self):
        dataloaders = {
            x: torch.utils.data.DataLoader(self.dataset()[x], batch_size=self.batch_size, shuffle=True)
            for x in ["train", "validation"]
        }
        
        return dataloaders
    
    
    def train_model(self,model, criterion, optimizer, scheduler, num_epochs,name='classicalModel'):
        since = time.time()
        best_model_wts = copy.deepcopy(model.state_dict())
        best_acc = 0.0
        best_loss = 10000.0  # Large arbitrary number
        best_acc_train = 0.0
        best_loss_train = 10000.0  # Large arbitrary number
        print("Training started:")
        dataloaders = self.dataset_dataloaders()
        dataset_sizes = self.dataset_sizes()
        
        
        for epoch in range(num_epochs):
    
            # Each epoch has a training and validation phase
            for phase in ["train", "validation"]:
                if phase == "train":
                    # Set model to training mode
                    model.train()
                else:
                    # Set model to evaluate mode
                    model.eval()
                running_loss = 0.0
                running_corrects = 0
    
                # Iterate over data.
#                n_batches = self.dataset_sizes()[phase] // batch_size
#                it = 0
#                
                for inputs, labels in dataloaders[phase]:
#                    since_batch = time.time()
                    batch_size_ = len(inputs)
                    inputs = inputs.to(self.device)
                    labels = labels.to(self.device)
                    optimizer.zero_grad()
    
                   
                    with torch.set_grad_enabled(phase == "train"):
                        outputs = None
                        if self.model_name == "inception_v3" and phase== "train":
                            outputs = model(inputs)
                            outputs = outputs[0]
                        else:
                            outputs = model(inputs)
        #                     print(outputs)
        #                     print(labels)
        #                     break
                        _, preds = torch.max(outputs, 1)
                        loss = criterion(outputs, labels)
                        if phase == "train":
                            loss.backward()
                            optimizer.step()
    
                    # Print iteration results
                    running_loss += loss.item() * batch_size_
                    batch_corrects = torch.sum(preds == labels.data).item()
                    running_corrects += batch_corrects
    #                print(
    #                    "Phase: {} Epoch: {}/{} Iter: {}/{} Batch time: {:.4f}\n".format(
    #                        phase,
    #                        epoch + 1,
    #                        num_epochs,
    #                        it + 1,
    #                        n_batches + 1,
    #                        time.time() - since_batch,
    #                    ),
    #                    end="\r",
    #                    flush=True,
    #                )
    #                it += 1
    
                # Print epoch results
                epoch_loss = running_loss / dataset_sizes[phase]
                epoch_acc = running_corrects / dataset_sizes[phase]
                print(
                    "Phase: {} Epoch: {}/{} Loss: {:.4f} Acc: {:.4f}        ".format(
                        "train" if phase == "train" else "validation \n ",
                        epoch + 1,
                        num_epochs,
                        epoch_loss,
                        epoch_acc,
                    )
                )
    
                # Check if this is the best model wrt previous epochs
                if phase == "validation" and epoch_acc > best_acc:
                    best_acc = epoch_acc
                    best_model_wts = copy.deepcopy(model.state_dict())
    #                torch.save(copy.deepcopy(model.state_dict()),MODEL_PATH +"/"+name+'.pth')
#                    torch.save(copy.deepcopy(model.state_dict()),MODEL_PATH +"/"+name+'.pt')
#                    torch.save(copy.deepcopy(model.state_dict()),MODEL_PATH +"/"+name+'revised'+'.pth',_use_new_zipfile_serialization=False)
                if phase == "validation" and epoch_loss < best_loss:
                    best_loss = epoch_loss
                if phase == "train" and epoch_acc > best_acc_train:
                    best_acc_train = epoch_acc
                if phase == "train" and epoch_loss < best_loss_train:
                    best_loss_train = epoch_loss
    
                # Update learning rate
                if phase == "train":
                    scheduler.step()
    
        # Print final results
        model.load_state_dict(best_model_wts)
        time_elapsed = time.time() - since
        print(
            "\n\nTraining completed in {:.0f}m {:.0f}s".format(time_elapsed // 60, time_elapsed % 60)
        )
        print("\n\nBest test loss: {:.4f} | Best test accuracy: {:.4f}".format(best_loss, best_acc))
        return model
    
    def get_crossEntropy_criterion(self):
        return nn.CrossEntropyLoss()
        
    def get_optima_optimizer(self,model,optimizer_name: str ="Adam",lr: int = 0.0004):
        optimizer = getattr(
            torch.optim, optimizer_name
        )(filter(lambda p:p.requires_grad, model.parameters()), lr)
        
        return optimizer
    
    def get_optima_Schedular(self,optimizer,step_size: int = 10,gamma_lr_schedular: float=0.1):
        scheduler = lr_scheduler.StepLR(
                optimizer, step_size=step_size, gamma=gamma_lr_schedular
        )
        return scheduler
        
        

