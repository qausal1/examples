from ._1config import get_model_keys

from ._6quantumModel import QuantumModel
from ._7pytorchHelper import pytorch_helper

import torch
import torchvision
from datetime import datetime
         
# key = [ip,front_layer,op,last_layer,entanglement_layer,middle_layer,measurement,fmap_depth,var_depth,model_id,fmap_id]

def test_model(quantum_circuit_params,q_device_params,ml_params,data_params):
  # print(len(key))
  # print(key)
  key=get_model_keys(quantum_circuit_params)
  # print(key)
  model_name=ml_params['model_name']
  n_qubits=quantum_circuit_params['n_qubits']
  
  model = QuantumModel(key,q_device_params,ml_params['n_classes'],model_name,n_qubits).get_model()
  model = QuantumModel(key,q_device_params,ml_params['n_classes'],model_name,n_qubits).get_model()
  device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
  print("Device is:",device)
  model.to(device)
  
      
  def load_model(model, path):
      device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
      model.load_state_dict(torch.load(path, map_location=device))
      model.eval()
      return model

  model=load_model(model,data_params['trained_model_path'])
  p1 = pytorch_helper(model,data_params['data_dir'],int(ml_params['batch_size']),model_name)

  dataloaders=p1.dataset_dataloaders()

  # outputss=[]
  # label=[]
  # model.eval()
  # with torch.no_grad():
  #   for _i,(inputs,labels) in enumerate(dataloaders["validation"]):
  #     inputs=inputs.to(device)
  #     labels=labels.to(device)
  #     label.append(labels)
  #     outputs=model(inputs)
  #     outputss.append(outputs)
      
  # all_label=[]
  # for l in label:
  #   for i in l:
  #     all_label.append(i.item())
  # import pandas as pd
  # df=pd.DataFrame(all_label,columns=['actual'])

  # preds=[]
  # for o in outputss:
  #   for i in o:
  #     op=[a.item() for a in i]
  #     # print(op[1])
  #     preds.append(op[1])
  # df['preds']=preds

  # from sklearn.metrics import accuracy_score
  # accuracy=accuracy_score(df['actual'],df['preds'].round())
  # print(accuracy)

  # df.to_csv('test_result_'+model_name+'_'+datetime.now().strftime("%Y_%m_%d_%H_%M")+'.csv',index=False)

  outputss=[]
  label=[]
  model.eval()
  with torch.no_grad():
    for _i,(inputs,labels) in enumerate(dataloaders["validation"]):
      inputs=inputs.to(device)
      labels=labels.to(device)
      label.append(labels)
      outputs=model(inputs)
      outputss.append(outputs)

  preds=[]
  for o in outputss:
    for i in o:
      op=[a.item() for a in i]
      # print(op[1])
      preds.append(op)
  all_label=[]
  for l in label:
    for i in l:
      all_label.append(i.item())
  import pandas as pd
  pred=pd.DataFrame(preds,columns=['Score'+str(i) for i in range(len(preds[0]))])
  pred['actual']=all_label
  pred.to_csv('test_result_'+model_name+'_'+datetime.now().strftime("%Y_%m_%d_%H_%M")+'.csv',index=False)


  pred_sing=pd.DataFrame(pred.iloc[:,0:-1].idxmax(axis=1),columns=['preds'])
  pred_sing['preds']=pred_sing['preds'].apply(lambda x: pred.columns.get_loc(x))

  from sklearn.metrics import accuracy_score
  accuracy_score=accuracy_score(pred['actual'].values,pred_sing.values)
  # print("accuracy of model:",accuracy_score)
  return accuracy_score





# test_model()