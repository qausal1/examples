from ._1config import get_model_keys

from ._6quantumModel import QuantumModel
from ._7pytorchHelper import pytorch_helper

import torch
import torchvision
from datetime import datetime
filename=datetime.now().strftime("%Y_%m_%d_%H_%M")

def train_model(quantum_circuit_params,q_device_params,ml_params,data_params):
    # print(len(key))
    key=get_model_keys(quantum_circuit_params)
    print(key)
    model_name=ml_params['model_name']
    n_qubits=quantum_circuit_params['n_qubits']

    model = QuantumModel(key,q_device_params,ml_params['n_classes'],model_name,n_qubits).get_model()
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model=model.to(device)

    p1 = pytorch_helper(model,data_params['data_dir'],int(ml_params['batch_size']),model_name)

    def load_model(model, path):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        model.load_state_dict(torch.load(path, map_location=device))
        # model.eval()
        return model
    try:
        trained_model_path=data_params['trained_model_path']
        model = load_model(model, trained_model_path)
        print('Model training started from previous saved model')
    except:
        print('No pretraied model found, Training started from beginning')

    criterion=p1.get_crossEntropy_criterion()
    optimizer1 = p1.get_optima_optimizer(model,ml_params['optimizer'],ml_params['lr'])
    scheduler = p1.get_optima_Schedular(optimizer1,ml_params['step_size'],ml_params['lr'])
    # num_epochs=3
    name=model_name

    model=p1.train_model(model,criterion,optimizer1,scheduler,num_epochs=ml_params['num_epochs'],name=model_name)
    dataloaders=p1.dataset_dataloaders()

    torch.save(model.state_dict(),
        'models/model_'+model_name+'_'+filename+'.pth')
    return model