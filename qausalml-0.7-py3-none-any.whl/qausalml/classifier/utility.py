# circuit creating; visualize the circuit 
# error correction : strategy 
# dataset creating ; dataset details; load default dataset
# training with own dataset
# test the performance of trained model
# performance metrics 
# adversarial
import os 
import pennylane as qml
import numpy as np
import matplotlib.pyplot as plt

import torch
import torchvision
import copy
from torchvision import datasets, transforms

from ._4quantumCircuit import Quantum_circuit
from ._1config import get_q_device, get_model_keys

from ._6quantumModel import QuantumModel
from ._7pytorchHelper import pytorch_helper


def visualize_quantum_circuit(quantum_circuit_params): 
    ip = quantum_circuit_params['ip']
    front_layer = '7'+str(quantum_circuit_params['front_layer'])
    op = quantum_circuit_params['op']
    last_layer =  str(quantum_circuit_params['last_layer'])
    entanglement_layer = quantum_circuit_params['entanglement_layer']
    middle_layer = str(quantum_circuit_params['middle_layer'])
    measurement = quantum_circuit_params['measurement']
    fmap_depth = 3
    var_depth = quantum_circuit_params['var_depth']
    fmap_id = 100
    model_id='Hybrid'
    n_qubits=quantum_circuit_params['n_qubits']
    dev=qml.device('default.qubit',wires=n_qubits)
    @qml.qnode(dev,interface='torch')
    def quantum_net(inputs,weights):
        qc=Quantum_circuit(ip,front_layer,op,
                        last_layer,entanglement_layer,
                        middle_layer,measurement,
                        fmap_depth,var_depth,
                        model_id,
                        fmap_id,
                        n_qubits)
        if qc.ip ==1:
            qc.front_layers(inputs)

        #using featuremap_id
        # qc.get_feature_map(inputs,n_qubits,int(qc.fmap_depth))


        for k in range(int(qc.var_depth)):
            qc.get_var_layer2(k,weights)

        qc.get_entanglement_layer(qc.entanglement_layer,True)

        if qc.op == 1:
            qc.last_layers(inputs)

        exp_vals = qc.get_expectation_value(int(qc.measurement))
        return tuple(exp_vals)
    
    inputs=np.random.rand(n_qubits)
    weight=np.random.rand(var_depth*len(middle_layer),n_qubits)
    # return print(qml.draw(quantum_net)(inputs,weight),
    #              "\n above circuit is the circuit with random weight initialized")
    fig=qml.draw_mpl(quantum_net,style='sketch')(inputs, weight)
    return fig

def print_q_device_info(device_params,n_qubits):
    return print(get_q_device(device_params,n_qubits))

         
# key = [ip,front_layer,op,last_layer,entanglement_layer,middle_layer,measurement,fmap_depth,var_depth,model_id,fmap_id]

def create_hybrid_model(quantum_circuit_params,q_device_params,ml_params,data_params):
    # print(len(key))
    key=get_model_keys(quantum_circuit_params)
    print(key)
    model_name=ml_params['model_name']
    n_qubits=quantum_circuit_params['n_qubits']

    model = QuantumModel(key,q_device_params,ml_params['n_classes'],model_name,n_qubits).get_model()
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print("Device is:",device)
    model.to(device)

    p1 = pytorch_helper(model,data_params['data_dir'],int(ml_params['batch_size']),model_name)

    def load_model(model, path):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        model.load_state_dict(torch.load(path, map_location=device))
        # model.eval()
        return model
    try:
        trained_model_path=data_params['trained_model_path']
        model = load_model(model, trained_model_path)
        print('Pretrained modelfound...')
    except:
        print('No pretraied model found, New hybrid model created')

    return model

class data_helper:
    def __init__(self,model,data_dir,model_name):
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.data_dir = data_dir
        self.model = model
        self.model.to(self.device)
        self.batch_size = 16
        self.model_name = model_name
        
    def dataset_transform(self):
        
        data_transforms = {
            "train": transforms.Compose(
                [
                    # transforms.RandomResizedCrop(224),     # uncomment for data augmentation
                    # transforms.RandomHorizontalFlip(),     # uncomment for data augmentation
                    transforms.Resize(256),
                    transforms.CenterCrop(224),
                    transforms.ToTensor(),
                    # Normalize input channels using mean values and standard deviations of ImageNet.
                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
                ]
            ),
            "test": transforms.Compose(
                [
                    transforms.Resize(256),
                    transforms.CenterCrop(224),
                    transforms.ToTensor(),
                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
                ]
            ),
            }
        
        return data_transforms
    
    def dataset_transform_inception(self):
        
        data_transforms = {
            "train": transforms.Compose(
                [
                    # transforms.RandomResizedCrop(224),     # uncomment for data augmentation
                    # transforms.RandomHorizontalFlip(),     # uncomment for data augmentation
                    transforms.Resize(256),
                    transforms.CenterCrop(299),
                    transforms.ToTensor(),
                    # Normalize input channels using mean values and standard deviations of ImageNet.
                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
                ]
            ),
            "test": transforms.Compose(
                [
                    transforms.Resize(256),
                    transforms.CenterCrop(299),
                    transforms.ToTensor(),
                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
                ]
            ),
            }
        
        return data_transforms
    
    
    def dataset(self):
        image_datasets = None
        if self.model_name == "inception_v3":
            image_datasets = {
                x if x == "train" else "validation": datasets.ImageFolder(
                    os.path.join(self.data_dir, x), self.dataset_transform_inception()[x]
                )
                for x in ["train", "test"]
            }
        else:
            image_datasets = {
                x if x == "train" else "validation": datasets.ImageFolder(
                    os.path.join(self.data_dir, x), self.dataset_transform()[x]
                )
                for x in ["train", "test"]
            }
            
            
#        print(image_datasets)
        return image_datasets
    
    def dataset_sizes(self):
        dataset_size = {x: len(self.dataset()[x]) for x in ["train", "validation"]}
        return dataset_size
    
    def class_names(self):
        class_names = self.dataset()["train"].classes
        return class_names
    
    def dataset_dataloaders(self):
        dataloaders = {
            x: torch.utils.data.DataLoader(self.dataset()[x], batch_size=self.batch_size, shuffle=True)
            for x in ["train", "validation"]
        }
        
        return dataloaders

    def get_data_arrays(self):
        dataloaders=self.dataset_dataloaders()
        X_train=[]
        Y_train=[]
        with torch.no_grad():
            for _i,(inputs,labels) in enumerate(dataloaders['train']):
                for l in labels:
                    Y_train.append(l.item())
                    im=inputs.numpy()
                for i in im:
                    X_train.append(i)

        X_train=np.array(X_train)
        Y_train=np.array(Y_train)

        X_test=[]
        Y_test=[]
        with torch.no_grad():
            for _i,(inputs,labels) in enumerate(dataloaders['validation']):
                for l in labels:
                    Y_test.append(l.item())
                    im=inputs.numpy()
                for i in im:
                    X_test.append(i)

        X_test=np.array(X_test)
        Y_test=np.array(Y_test)

        return X_train,Y_train,X_test,Y_test