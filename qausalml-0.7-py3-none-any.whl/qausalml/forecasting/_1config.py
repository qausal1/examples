# CONFIG.PY
import pennylane as qml
import json
import os
# import yaml
# from yaml.loader import SafeLoader

model_directory = 'models'
os.path.exists(model_directory)
if not os.path.exists(model_directory):
    os.makedirs(model_directory)

# with open('config.yaml') as f:
#     data = yaml.load(f, Loader=SafeLoader)

# data_params = data['data_params']
# ml_params = data['ml_params']
# q_device_params = data['q_device_params']
# quantum_circuit_params = data['quantum_circuit_params']

def get_model_keys(quantum_circuit_params):
  # n_qubits=quantum_circuit_params['n_qubits']
  ip = quantum_circuit_params['ip']
  front_layer = '7'+str(quantum_circuit_params['front_layer'])
  op = quantum_circuit_params['op']
  last_layer = str(quantum_circuit_params['last_layer'])
  entanglement_layer = quantum_circuit_params['entanglement_layer']
  middle_layer = str(quantum_circuit_params['middle_layer'])
  measurement = quantum_circuit_params['measurement']
  fmap_depth = 3
  var_depth = quantum_circuit_params['var_depth']
  fmap_id = 100
  n_qubits = quantum_circuit_params['n_qubits']
  key = [ip, front_layer, op, last_layer, entanglement_layer,
          middle_layer, measurement, fmap_depth, var_depth, 'Hybrid', fmap_id,n_qubits]
  return key


# def get_q_device(device_params, n_qubits):
#     use_real_q_hw = device_params['use_real_q_hw']
#     device_platform = device_params['device_platform']
#     api_token = device_params['api_token']
#     real_q_device_name = device_params['real_q_device_name']

#     if use_real_q_hw == False:
#         if device_platform == 'pennylane':
#             q_dev = qml.device('default.qubit', wires=n_qubits)
#         elif device_platform == 'qiskit':
#             q_dev = qml.device('qiskit.aer', wires=n_qubits)
#         elif device_platform == 'cirq':
#             q_dev = qml.device('cirq.simulator', wires=n_qubits)
#         elif device_platform == 'ionq':
#             q_dev = qml.device('ionq.simulator', wires=n_qubits)
#         else:
#             print("Please select one of the simulator device. Available simulator devices are 'pennylane', 'qiskit','cirq' and 'ionq' ")
#     elif use_real_q_hw == True:
#         if api_token:
#             print('api token is provided and can execute using real quantum hardware')
#             if device_platform == 'pennylane':
#                 print(
#                     "please select any premium quantum hardware:'qiskit', 'cirq', 'ionq' ")
#             elif device_platform == 'qiskit':
#                 q_dev = qml.device('qiskit.ibmq', wires=n_qubits, backend=real_q_device_name,
#                                    ibmqx_token=api_token)
#             elif device_platform == 'cirq':
#                 pass
#             elif device_platform == 'ionq':
#                 pass
#             else:
#                 print(
#                     "please select any premium quantum hardware:'qiskit', 'cirq', 'ionq'")
#         else:
#             print("Error: no valid api token provided")
#     else:
#         print('Please set use_real_q_hw either True of False')
#     return q_dev

def get_q_device(device_params, n_qubits):
  use_real_q_hw = device_params['use_real_q_hw']
  device_platform = device_params['device_platform']
  api_token = device_params['api_token']
  real_q_device_name = device_params['real_q_device_name']

  if use_real_q_hw== False:
    if device_platform == 'pennylane':
      q_dev = qml.device('default.qubit',wires=n_qubits)
    elif device_platform == 'qiskit':
      q_dev = qml.device('qiskit.aer',wires=n_qubits)
    elif device_platform == 'cirq':
      q_dev = qml.device('cirq.simulator', wires=n_qubits)
    elif device_platform == 'ionq':
      q_dev = qml.device('ionq.simulator',wires=n_qubits)
    elif device_platform == 'qulacs':
      q_dev = qml.device('qulacs.simulator',wires=n_qubits)
    else:
      print("Please select one of the simulator device. Available simulator devices are 'pennylane', 'qiskit','cirq' and 'ionq' ")
  elif use_real_q_hw == True:
      if api_token:
        print('api token is provided and can execute using real quantum hardware')
        if device_platform == 'pennylane':
          print("please select any premium quantum hardware:'qiskit', 'cirq', 'ionq' ")
        elif device_platform == 'qiskit':
          q_dev = qml.device('qiskit.ibmq', wires=n_qubits, backend=real_q_device_name,
                  ibmqx_token=api_token)
        elif device_platform == 'cirq':
          pass
        elif device_platform == 'ionq':
          pass
        else:
          print("please select any premium quantum hardware:'qiskit', 'cirq', 'ionq'")
      else:
        print("Error: no valid api token provided")
  else:
      print('Please set use_real_q_hw either True of False')
  return q_dev