import os 
import pennylane as qml
import numpy as np
import matplotlib.pyplot as plt

import torch
import torchvision
import copy
from torchvision import datasets, transforms

from ._4quantumCircuit import Quantum_circuit
from ._1config import get_q_device, get_model_keys

def create_quantum_layer(quantum_circuit_params,q_device_params):
	key=get_model_keys(quantum_circuit_params)
	ip,front_layer,op,last_layer,entanglement_layer,middle_layer,measurement,fmap_depth,var_depth,model_id,fmap_id,n_qubits=key
	dev = get_q_device(q_device_params,n_qubits)

	def quantum_net(inputs, weights):
		qc = Quantum_circuit(ip,
			front_layer,
			op,
			last_layer,
			entanglement_layer,
			middle_layer,
			measurement,
			fmap_depth,
			var_depth,
			model_id ,
			fmap_id,
			n_qubits)

		if qc.ip ==1:
			qc.front_layers(inputs)

		for k in range(int(qc.var_depth)):
			qc.get_var_layer2(k,weights)

		qc.get_entanglement_layer(qc.entanglement_layer,True)

		if qc.op == 1:
			qc.last_layers(inputs)

		exp_vals = qc.get_expectation_value(int(qc.measurement))
		return tuple(exp_vals)

	weight_shapes={'weights':(var_depth * len(middle_layer) ,n_qubits)}
	# weight_shapes={'weights':(5*len('4'),4)}
	qnode=qml.QNode(quantum_net,dev,interface='torch')
	qlayer=qml.qnn.TorchLayer(qnode,weight_shapes)
	return qlayer
