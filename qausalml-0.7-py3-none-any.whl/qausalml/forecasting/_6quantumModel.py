# DEFINE THE LSTM NETWORK:
import torch
import numpy as np 
import torch.nn as nn
import pennylane as qml 

from ._5quantumNet import create_quantum_layer

def create_hybrid_qlstm_model(quantum_circuit_params,q_device_params,ml_params):
  device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
  class hybridLSTM(nn.Module):

      def __init__(self,n_qubits, input_size, hidden_size,num_classes=1, num_layers=1):
          super(hybridLSTM, self).__init__()

          self.num_classes = num_classes
          self.num_layers = num_layers
          self.input_size = input_size
          self.hidden_size = hidden_size
          self.hidden_size2 = n_qubits
          self.n_qubits = n_qubits
          # self.seq_length = seq_length

          self.lstm1 = nn.LSTM(input_size=input_size, hidden_size=hidden_size,
                              num_layers=num_layers, batch_first=True)
          self.lstm2 = nn.LSTM(input_size=hidden_size, hidden_size=self.hidden_size2,
                              num_layers=num_layers, batch_first=True)
          # self.lstm2 = nn.LSTM(input_size=hidden_size, hidden_size=hidden_size,
          #                     num_layers=num_layers, batch_first=True)

          # qnode=qml.QNode(quantum_net,dev,interface='torch')
          # self.qlayer = qml.qnn.TorchLayer(qnode, weight_shapes)
          self.qlayer = create_quantum_layer(quantum_circuit_params,q_device_params)

          self.fc = nn.Linear(self.hidden_size2, num_classes)

      def forward(self, x):
          h_0=torch.randn(self.num_layers, x.size(0), self.hidden_size).requires_grad_()
          h_0=h_0.to(device)
          c_0=torch.randn(self.num_layers, x.size(0), self.hidden_size).requires_grad_()
          c_0=c_0.to(device)
          # Propagate input through LSTM1
          output, (h_n,c_n) = self.lstm1(x, (h_0, c_0))
          output=output.to(device)

          # h_2=torch.randn(self.num_layers, x.size(0), self.hidden_size2).requires_grad_()
          h_2 = h_n # for same number of 2 lstms hidden size
          h_2=h_2.to(device)
          # c_2=torch.randn(self.num_layers, x.size(0), self.hidden_size2).requires_grad_()
          c_2 = c_n # for same number of 2 lstms hidden size
          c_2=c_2.to(device)
          # Propagate input through LSTM1
          output, (h_n,c_n) = self.lstm2(output, (h_2, c_2))

          q_in = output[:,-1,:]
          q_in=(q_in)*np.pi/2
          q_out=torch.Tensor(0,self.n_qubits)
          q_out=q_out.to(device)
          for elem in q_in:
            q_out_elem = self.qlayer(elem).float().unsqueeze(0)
            q_out = torch.cat((q_out, q_out_elem))

          q_out=q_out.view(-1,self.n_qubits)

          out = self.fc(q_out)

          return out

  n_qubits=quantum_circuit_params['n_qubits']
  input_size=ml_params['input_size']
  hidden_size=ml_params['hidden_size']
  model= hybridLSTM(n_qubits,input_size,hidden_size)
  return model        