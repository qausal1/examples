from ._1config import get_model_keys

# from ._6quantumModel import QuantumModel
# from ._7pytorchHelper import pytorch_helper

import torch
import torchvision
from datetime import datetime
         
# TEST TRIANED MODEL FROM API 
from datetime import datetime
import torch
filename=datetime.now().strftime("%Y_%m_%d_%H_%M")
def test_forecasting_model(model,data_params,ml_params,X_test,Y_test,scaler):
  def load_model(model, path):
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model.load_state_dict(torch.load(path, map_location=device))
    return model

  trained_model_path=data_params['trained_model_path']
  model = load_model(model, trained_model_path)

  Y_pred=model(X_test)
  Y_pred=Y_pred.data.numpy()
  Y_pred = scaler.inverse_transform(Y_pred)
  Y_test = scaler.inverse_transform(Y_test)
  from sklearn.metrics import mean_absolute_error
  mae=mean_absolute_error(Y_test,Y_pred)
  import pandas as pd 
  df=pd.DataFrame({'actual':Y_test.flatten(), 'pred':Y_pred.flatten()})
  df.to_csv('test_result_forecasting'+filename+'.csv',index=False)
  return mae