# FUNCTION TO TRAIN THE MODEL AND RETURN THE TRAINED MODEL
from datetime import datetime
import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler

import pennylane as qml

import torch
import torch.nn as nn
from torch.autograd import Variable 


filename=datetime.now().strftime("%Y_%m_%d_%H_%M")
def train_forecasting_model(model,data_params,ml_params,X_train,Y_train):
	def load_model(model, path):
		device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
		model.load_state_dict(torch.load(path, map_location=device))
		return model
	try:
		trained_model_path=data_params['trained_model_path']
		model = load_model(model, trained_model_path)
		print('Model training started from previous saved model')
	except:
		print('No pretraied model found, Training started from beginning')
	criterion = torch.nn.MSELoss()    # mean-squared error for regression
	if ml_params['optimizer']=='adam':
		optimizer = torch.optim.Adam(model.parameters(), lr=ml_params['lr'])
	elif ml_params['optimizer']=='sgd':
		optimizer=torch.optim.SGD(model.parameters(), lr=ml_params['lr'])

	# TRAIN THE MODEL:
	num_epochs=ml_params['num_epochs']
	import copy
	for epoch in range(num_epochs):
		model.train()
		outputs = model(X_train)
		optimizer.zero_grad()

		# obtain the loss function
		loss = criterion(outputs, Y_train)

		loss.backward()

		optimizer.step()
		print("Epoch: %d, loss: %1.5f" % (epoch, loss.item()))

	torch.save(model.state_dict(),
	'models/model_hqclstm_'+filename+'.pth')
	return model