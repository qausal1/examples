# circuit creating; visualize the circuit 
# error correction : strategy 
# dataset creating ; dataset details; load default dataset
# training with own dataset
# test the performance of trained model
# performance metrics 
# adversarial
import os 
import pennylane as qml

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import torch
import torchvision
import copy
from torchvision import datasets, transforms
from torch.autograd import Variable

from sklearn.preprocessing import MinMaxScaler

from ._4quantumCircuit import Quantum_circuit
from ._1config import get_q_device, get_model_keys

# from ._6quantumModel import QuantumModel
# from ._7pytorchHelper import pytorch_helper


def visualize_quantum_circuit(quantum_circuit_params): 
	ip = quantum_circuit_params['ip']
	front_layer = '7'+str(quantum_circuit_params['front_layer'])
	op = quantum_circuit_params['op']
	last_layer =  str(quantum_circuit_params['last_layer'])
	entanglement_layer = quantum_circuit_params['entanglement_layer']
	middle_layer = str(quantum_circuit_params['middle_layer'])
	measurement = quantum_circuit_params['measurement']
	fmap_depth = quantum_circuit_params['fmap_depth']
	var_depth = quantum_circuit_params['var_depth']
	fmap_id = quantum_circuit_params['fmap_id']
	model_id='Hybrid'
	n_qubits=quantum_circuit_params['n_qubits']
	dev=qml.device('default.qubit',wires=n_qubits)
	@qml.qnode(dev,interface='torch')
	def quantum_net(inputs,weights):
		qc=Quantum_circuit(ip,front_layer,op,
										last_layer,entanglement_layer,
										middle_layer,measurement,
										fmap_depth,var_depth,
										model_id,
										fmap_id,
										n_qubits)
		if qc.ip ==1:
			qc.front_layers(inputs)

		for k in range(int(qc.var_depth)):
			qc.get_var_layer2(k,weights)

		qc.get_entanglement_layer(qc.entanglement_layer,True)

		if qc.op == 1:
			qc.last_layers(inputs)

		exp_vals = qc.get_expectation_value(int(qc.measurement))
		return tuple(exp_vals)
	
	inputs=np.random.rand(n_qubits)
	weight=np.random.rand(var_depth*len(middle_layer),n_qubits)
	return print(qml.draw(quantum_net)(inputs,weight),
	             "\n above circuit is the circuit with random weight initialized")
	print('The quantum circuit is the circuit with random weight initialized')
	fig=qml.draw_mpl(quantum_net,style='sketch')(inputs, weight)
	return fig

def print_q_device_info(device_params,n_qubits):
	return print(get_q_device(device_params,n_qubits))

#CREATING QUANTUM NEURAL NETWORK LAYER FROM CIRCUIT 
def create_quantum_layer(quantum_circuit_params,q_device_params):
	key=get_model_keys(quantum_circuit_params)
	ip,front_layer,op,last_layer,entanglement_layer,middle_layer,measurement,fmap_depth,var_depth,model_id,fmap_id,n_qubits=key
	dev = get_q_device(q_device_params,n_qubits)

	def quantum_net(inputs, weights):
		qc = Quantum_circuit(ip,
			front_layer,
			op,
			last_layer,
			entanglement_layer,
			middle_layer,
			measurement,
			fmap_depth,
			var_depth,
			model_id ,
			fmap_id,
			n_qubits)

		if qc.ip ==1:
			qc.front_layers(inputs)

		for k in range(int(qc.var_depth)):
			qc.get_var_layer2(k,weights)

		qc.get_entanglement_layer(qc.entanglement_layer,True)

		if qc.op == 1:
			qc.last_layers(inputs)

		exp_vals = qc.get_expectation_value(int(qc.measurement))
		return tuple(exp_vals)

	weight_shapes={'weights':(var_depth * len(middle_layer) ,n_qubits)}
	# weight_shapes={'weights':(5*len('4'),4)}
	qnode=qml.QNode(quantum_net,dev,interface='torch')
	qlayer=qml.qnn.TorchLayer(qnode,weight_shapes)
	return qlayer

#PROCESSING DATA FOR INPUT TO THE HYBRID-LSTM
def preprocess_data(data_params):
  csv_file_path=data_params['csv_filepath']
  test_size=data_params['test_size']
  seq_length=data_params['seq_length']
  target_col=data_params['target_col']
  data=pd.read_csv(csv_file_path)
  data=data.select_dtypes(exclude=['object','datetime64','timedelta'])
  train_data=data.head(int((1-test_size)*len(data)))
  init_test_data=data[len(train_data):]
  past_seq_data=train_data.tail(seq_length)
  test_data = pd.concat([past_seq_data,init_test_data],ignore_index=True)

  scaler=MinMaxScaler()
  training_data=scaler.fit_transform(train_data)
  testing_data=scaler.transform(test_data)
  target_col_index=train_data.columns.get_loc(target_col)
  target_col_index
  X_train=[]
  Y_train=[]
  X_test=[]
  Y_test=[]
  for i in range(seq_length,training_data.shape[0]):
    X_train.append(training_data[i-seq_length:i])
    Y_train.append(training_data[i,0])

  for i in range(seq_length,testing_data.shape[0]):
    X_test.append(testing_data[i-seq_length:i])
    Y_test.append(testing_data[i,0])

  # converting into numpy array
  X_train,Y_train=np.array(X_train),np.array(Y_train).reshape(-1,1)
  X_test,Y_test=np.array(X_test),np.array(Y_test).reshape(-1,1)
  X_train = Variable(torch.Tensor(X_train))
  Y_train = Variable(torch.Tensor(Y_train))
  X_test = Variable(torch.Tensor(X_test))
  Y_test = Variable(torch.Tensor(Y_test))

  return X_train,X_test,Y_train,Y_test,scaler

#PROCESSING DATA FOR INPUT TO THE HYBRID-LSTM
# def preprocess_data(csv_file_path,target_col_name,seq_length=40,test_size=0.25):
#   data=pd.read_csv(csv_file_path)
#   data=data.select_dtypes(exclude=['object','datetime64','timedelta'])
#   train_data=data.head(int((1-test_size)*len(data)))
#   init_test_data=data[len(train_data):]
#   past_seq_data=train_data.tail(seq_length)
#   test_data = pd.concat([past_seq_data,init_test_data],ignore_index=True)

#   scaler=MinMaxScaler()
#   training_data=scaler.fit_transform(train_data)
#   testing_data=scaler.transform(test_data)
#   target_col_index=train_data.columns.get_loc(target_col_name)
#   target_col_index
#   X_train=[]
#   Y_train=[]
#   X_test=[]
#   Y_test=[]
#   for i in range(seq_length,training_data.shape[0]):
#     X_train.append(training_data[i-seq_length:i])
#     Y_train.append(training_data[i,0])

#   for i in range(seq_length,testing_data.shape[0]):
#     X_test.append(testing_data[i-seq_length:i])
#     Y_test.append(testing_data[i,0])

#   # converting into numpy array
#   X_train,Y_train=np.array(X_train),np.array(Y_train).reshape(-1,1)
#   X_test,Y_test=np.array(X_test),np.array(Y_test).reshape(-1,1)
#   X_train = Variable(torch.Tensor(X_train))
#   Y_train = Variable(torch.Tensor(Y_train))
#   X_test = Variable(torch.Tensor(X_test))
#   Y_test = Variable(torch.Tensor(Y_test))

#   return X_train,X_test,Y_train,Y_test,scaler
